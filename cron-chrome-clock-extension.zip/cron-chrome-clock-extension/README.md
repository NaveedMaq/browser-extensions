
# Cron | Chrome Simple Clock Homepage

Simple digital clock for chrome browser


## Tech Stack

**Client:** HTML 5, CSS 3, JS


## Screenshots

![App Screenshot](https://github.com/NaveedMaq/small-web-projects/blob/main/projects/simple-clock/screenshots/screenshot1.png)

